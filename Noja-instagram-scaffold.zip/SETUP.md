# Setup

## 1. Runtime and connection method

Install Node.js 20+ and a current Codex CLI/Desktop host with local stdio support.
Check `node --version`, `npx --version`, and `codex --version`.
The scaffold was prepared with Codex CLI 0.163.0 and meta-mcp 2.2.2.

Choose ONE path:

**Native Codex project configuration (recommended):** open this repository as a
trusted project. Codex reads `.codex/config.toml`; inspect `/mcp` in a new session.
Project configuration is not loaded for an untrusted project. Use `codex mcp list`
to inspect the effective configuration without calling Instagram.

**Optional plugin installation:** `.codex-plugin/plugin.json` is still a supported
compatibility format; its paths resolve from the repository root. Register this
local repository as a marketplace with `codex plugin marketplace add .`, then
browse `codex plugin list --available --json` or `/plugins` and install
`noja-instagram-automation` from `noja-local`. Start a new session. Before using
this path, remove the `[mcp_servers.meta_instagram]` table from your local project
config or set its `enabled = false`, to avoid duplicate connections. Keep the
plugin's server enabled. Opening the repository does not install the plugin.
A portable Agent Plugins manifest is optional; the supported compatibility layout
is retained here to match the requested files.

Both configurations pin `npx -y @mikusnuz/meta-mcp@2.2.2`, forward named environment
variables with `env_vars`, and expose the same read-only tool allowlist.
No token values or `${TOKEN}` substitutions are stored in configuration files.
Review upstream code before changing the pinned version.

## 2. Meta app and account

This version uses **Instagram Graph API / Messaging with Facebook Login**.
Do not mix Instagram Login `instagram_business_*` scopes or tokens into this
configuration without changing and validating the underlying API integration.

1. Use an Instagram Professional account (Business or Creator) linked to a
   Facebook Page you manage. The authorizing person needs the relevant Page tasks.
2. Create/configure a Meta developer Business app with the Instagram API and
   Facebook Login for Business/messaging use cases available in its dashboard.
   Meta dashboard labels can change; select the Facebook Login integration.
3. Configure the OAuth redirect URI, privacy policy and data-deletion endpoint.
   Add app roles/testers and accept invitations for development testing.
4. Request only the permissions needed for the selected features:

| Feature | Facebook Login permissions |
| --- | --- |
| Profile/media and Page discovery | `instagram_basic`, `pages_show_list`, `pages_read_engagement` |
| Comment reads and future replies/Private Replies | `instagram_manage_comments` |
| Insights | `instagram_manage_insights` |
| Conversations and future DMs | `instagram_manage_messages`; this package also requires `pages_manage_metadata` |
| Future Page/webhook subscriptions | `pages_manage_metadata` and product-specific access |
| Future publishing only | `instagram_content_publish` |

`business_management` may be needed for specific Business Manager asset-discovery
flows; it is not a blanket requirement. Do not request publishing/deletion scopes
for the initial read-only connection. For accounts outside app roles, obtain the
required Advanced Access/App Review, business verification where Meta requires
it, and switch the app to Live. Role-only testing does not prove production access.

## 3. Credentials

Copy `.env.example` to `.env` locally and fill it using a secure local editor or
secret manager. Do not paste tokens into chats, commit messages or logs.

| Variable | Meaning |
| --- | --- |
| `INSTAGRAM_ACCESS_TOKEN` | Authorized Facebook Login user access token for Instagram Graph API; obtain a long-lived token when appropriate |
| `INSTAGRAM_USER_ID` | Linked Instagram Professional account ID, not a username or Page ID |
| `INSTAGRAM_MESSAGING_ACCESS_TOKEN` | Access token of the linked Facebook Page, with messaging access |
| `INSTAGRAM_PAGE_ID` | That linked Facebook Page ID |
| `META_APP_ID` / `META_APP_SECRET` | Same Meta app; only needed by token and app-management tools, currently excluded from the allowlist |
| `META_WEBHOOK_VERIFY_TOKEN` | Random value chosen by you for the future webhook challenge; not an access token and not consumed by meta-mcp |

Retrieve the authorized Pages with `/me/accounts` and the selected Page's linked
`instagram_business_account`; securely retain that Page's access token for
messaging. Exchange the user token through Meta's official server-side token
flow. Page tokens and user tokens have different lifetimes and revocation rules;
monitor expiry and permissions rather than assuming a permanent token.

Neither Codex nor this MCP package automatically loads `.env`. Export the values
in the environment of the process launching Codex. For a locally edited, trusted
shell-compatible `.env`, a POSIX shell example is:

```sh
set -a
. ./.env
set +a
codex
```

Sourcing executes shell syntax; use only your own file. GUI clients need the
credentials supplied to their actual launch environment/secret mechanism;
a terminal export does not necessarily reach an already running desktop app.

`.gitignore` excludes local environment files and common credential artifacts.
That does not replace reviewing staged content for secrets before each commit.

## 4. Validation

Without credentials, an MCP `initialize` handshake and `tools/list` can verify
installation and tool discovery. They do not establish Instagram authorization.
A bare `npx -y @mikusnuz/meta-mcp@2.2.2` starts a stdio server waiting for protocol
input; silence is normal and does not mean the account is connected.

After supplying credentials, restart Codex and request `ig_get_profile`, then
`ig_get_media_list` with limit 5. Test comments, insights and conversations only
if the corresponding permissions are granted. Do not send messages, comments,
posts, or subscribe webhooks as part of connection validation.

### Scaffold verification (2026-10-25)

- Codex CLI 0.163.0 loaded the native project configuration from a trusted project.
- In an isolated Codex home, the marketplace entry was discovered and the plugin
  installed successfully; the user's normal Codex configuration was not changed.
- meta-mcp 2.2.2 completed MCP initialization and returned 66 tools. All 11
  configured read-only tool names were present. No `tools/call` was sent.
- Both configurations agree on package version, forwarded environment names and
  tool allowlist. JSON/TOML parsing, empty template values and common secret
  patterns were checked. Account connectivity and Meta App Review remain untested.

## 5. Comment → DM → Lead roadmap (not implemented)

1. Build an HTTPS webhook endpoint. Answer Meta's verification challenge using
   `META_WEBHOOK_VERIFY_TOKEN`; validate `X-Hub-Signature-256` against the **raw**
   request body with `META_APP_SECRET`. Subscribe the relevant Instagram comments
   and messaging fields and the authorized account/Page using Meta's current flow.
2. Acknowledge valid events quickly and enqueue processing. Persist deduplication
   keys for account/comment/event and outgoing actions; handle webhook retries,
   job retries and ambiguous API failures without blindly resending.
3. Classify comment intent/keywords against an approved Noja ruleset. Start with
   dry-run previews and a stored `automation_enabled = false` setting. Hand off
   clinical questions; never invent prices or medical outcomes.
4. Add a **Private Replies** API adapter for an eligible comment. The pinned
   package has no such tool: `ig_send_message(recipient_id, message)` is for an
   existing user-initiated conversation, not an arbitrary commenter. Use Meta's
   comment-based private-reply contract for the selected login product, not the
   commenter's public ID. Validate current eligibility, the usual one-reply and
   seven-day limit (Live has tighter constraints), and applicable permissions.
5. Wait for the person's reply before conversational follow-ups; enforce Meta's
   applicable messaging window (normally 24 hours after their message), opt-out
   and rate limits. A comment alone does not authorize unlimited automated DMs.
6. Save minimal consented lead data to a database/CRM with source event, status,
   handoff owner and retention controls. Avoid collecting medical details/photos
   by default. Provide human escalation, audit records with token/PII redaction,
   a kill switch and monitoring for expiry, errors and queue failures.
7. Test with app-role accounts and replayed webhook fixtures. Enable only the
   approved write tools/workflow after explicit authorization. MCP alone is not
   a scheduler, queue, database or 24/7 automation worker.

No webhook is deployed or subscribed and no Instagram write is performed by this
scaffold. Production delivery needs the service above and a real account test.
