# Noja Instagram Automation

Instagram automation scaffold for **Noja Kasht**, using Meta's official APIs
through `@mikusnuz/meta-mcp@2.2.2` (Node.js 20+).

This repository contains configuration and playbooks, not a running webhook
service or a finished Comment → DM → Lead application. No credentials are bundled.

## Current status

- The default MCP tool allowlist exposes profile, media, insights, comments and
  conversation reads only. Sending, publishing, moderation, token tools and
  webhook changes are excluded. This is a client tool restriction, not a
  read-only Meta credential; keep token permissions minimal too.
- The upstream server includes write tools, but enabling them requires a
  deliberate configuration change and authorization for the workflow.
- Account connectivity remains unverified until real credentials are supplied.
- Generic DM sending requires an existing user-initiated conversation. The pinned
  server has no dedicated comment-triggered Private Replies tool.

## Files

- `AGENTS.md`: Noja brand rules and operating constraints.
- `skills/instagram-automation/SKILL.md`: reusable Instagram playbook.
- `.codex/config.toml`: native project MCP configuration for trusted Codex projects.
- `.codex-plugin/plugin.json` and `.mcp.json`: supported Codex compatibility plugin.
- `.agents/plugins/marketplace.json`: optional local plugin catalog.
- `.env.example`: empty configuration template; never put real values in Git.
- `SETUP.md`: connection, permissions, validation and automation roadmap.

## Start

Follow [SETUP.md](SETUP.md). Choose the native project configuration or plugin
installation so that the same server is not started twice. Opening the folder
alone does not install its plugin. A local stdio process requires a Codex host
with Node.js and credentials; it is not a hosted ChatGPT web MCP endpoint.

First authenticated request after setup:

> Use the instagram-automation skill and meta_instagram. Verify my profile and
> show five recent posts using read-only tools. Do not send or publish anything.

## References

- [Codex MCP configuration](https://developers.openai.com/codex/mcp)
- [Plugin packaging and supported compatibility layout](https://developers.openai.com/codex/plugins/build)
- [Pinned upstream package](https://www.npmjs.com/package/@mikusnuz/meta-mcp/v/2.2.2)
